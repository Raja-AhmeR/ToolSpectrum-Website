/****************************************************
*  project: wondershare frontend codex 2018         *
*  description: configuration overrides for op      *
*  author: mazq@wondershare.cn                      *
*  update: 190507                                   *
****************************************************/

/** configuration overrides **/
var wscConf = {}
wscConf.setting_style_font_family = ['Raleway:400,700,800']

// wscConf.path_base = './assets'
// check wsc-common.js wsc.store part for details
