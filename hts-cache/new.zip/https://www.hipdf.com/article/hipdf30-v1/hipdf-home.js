/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/components/login/loginDialog.vue":
/*!**********************************************!*\
  !*** ./src/components/login/loginDialog.vue ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _loginDialog_vue_vue_type_template_id_4fc5ef0b_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true& */ \"./src/components/login/loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true&\");\n/* harmony import */ var _loginDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loginDialog.vue?vue&type=script&lang=js& */ \"./src/components/login/loginDialog.vue?vue&type=script&lang=js&\");\n/* harmony import */ var _loginDialog_vue_vue_type_style_index_0_id_4fc5ef0b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true& */ \"./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true&\");\n/* harmony import */ var _node_modules_vue_vue_loader_v15_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/@vue/vue-loader-v15/lib/runtime/componentNormalizer.js */ \"./node_modules/@vue/vue-loader-v15/lib/runtime/componentNormalizer.js\");\n\n\n\n;\n\n\n/* normalize component */\n\nvar component = (0,_node_modules_vue_vue_loader_v15_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__[\"default\"])(\n  _loginDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _loginDialog_vue_vue_type_template_id_4fc5ef0b_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,\n  _loginDialog_vue_vue_type_template_id_4fc5ef0b_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,\n  false,\n  null,\n  \"4fc5ef0b\",\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"src/components/login/loginDialog.vue\"\n/* harmony default export */ __webpack_exports__[\"default\"] = (component.exports);\n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?");

/***/ }),

/***/ "./src/views/home/home.vue":
/*!*********************************!*\
  !*** ./src/views/home/home.vue ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _home_vue_vue_type_template_id_39f87be5_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.vue?vue&type=template&id=39f87be5&scoped=true& */ \"./src/views/home/home.vue?vue&type=template&id=39f87be5&scoped=true&\");\n/* harmony import */ var _home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.vue?vue&type=script&lang=js& */ \"./src/views/home/home.vue?vue&type=script&lang=js&\");\n/* harmony import */ var _node_modules_vue_vue_loader_v15_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/@vue/vue-loader-v15/lib/runtime/componentNormalizer.js */ \"./node_modules/@vue/vue-loader-v15/lib/runtime/componentNormalizer.js\");\n\n\n\n\n\n/* normalize component */\n;\nvar component = (0,_node_modules_vue_vue_loader_v15_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"])(\n  _home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _home_vue_vue_type_template_id_39f87be5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,\n  _home_vue_vue_type_template_id_39f87be5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,\n  false,\n  null,\n  \"39f87be5\",\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"src/views/home/home.vue\"\n/* harmony default export */ __webpack_exports__[\"default\"] = (component.exports);\n\n//# sourceURL=webpack://hipdf/./src/views/home/home.vue?");

/***/ }),

/***/ "./src/components/login/loginDialog.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./src/components/login/loginDialog.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!../../../node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./loginDialog.vue?vue&type=script&lang=js& */ \"./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=script&lang=js&\");\n /* harmony default export */ __webpack_exports__[\"default\"] = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?");

/***/ }),

/***/ "./src/views/home/home.vue?vue&type=script&lang=js&":
/*!**********************************************************!*\
  !*** ./src/views/home/home.vue?vue&type=script&lang=js& ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!../../../node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./home.vue?vue&type=script&lang=js& */ \"./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/views/home/home.vue?vue&type=script&lang=js&\");\n /* harmony default export */ __webpack_exports__[\"default\"] = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack://hipdf/./src/views/home/home.vue?");

/***/ }),

/***/ "./src/components/login/loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true&":
/*!*****************************************************************************************!*\
  !*** ./src/components/login/loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true& ***!
  \*****************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": function() { return /* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_loaders_templateLoader_js_ruleSet_1_rules_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_template_id_4fc5ef0b_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render; },\n/* harmony export */   \"staticRenderFns\": function() { return /* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_loaders_templateLoader_js_ruleSet_1_rules_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_template_id_4fc5ef0b_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }\n/* harmony export */ });\n/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_loaders_templateLoader_js_ruleSet_1_rules_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_template_id_4fc5ef0b_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!../../../node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!../../../node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true& */ \"./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true&\");\n\n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?");

/***/ }),

/***/ "./src/views/home/home.vue?vue&type=template&id=39f87be5&scoped=true&":
/*!****************************************************************************!*\
  !*** ./src/views/home/home.vue?vue&type=template&id=39f87be5&scoped=true& ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": function() { return /* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_loaders_templateLoader_js_ruleSet_1_rules_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_home_vue_vue_type_template_id_39f87be5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render; },\n/* harmony export */   \"staticRenderFns\": function() { return /* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_loaders_templateLoader_js_ruleSet_1_rules_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_home_vue_vue_type_template_id_39f87be5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }\n/* harmony export */ });\n/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_40_use_0_node_modules_vue_vue_loader_v15_lib_loaders_templateLoader_js_ruleSet_1_rules_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_home_vue_vue_type_template_id_39f87be5_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!../../../node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!../../../node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./home.vue?vue&type=template&id=39f87be5&scoped=true& */ \"./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/views/home/home.vue?vue&type=template&id=39f87be5&scoped=true&\");\n\n\n//# sourceURL=webpack://hipdf/./src/views/home/home.vue?");

/***/ }),

/***/ "./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true&":
/*!********************************************************************************************************!*\
  !*** ./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true& ***!
  \********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_vue_style_loader_index_js_clonedRuleSet_22_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_22_use_1_node_modules_vue_vue_loader_v15_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_22_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_22_use_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_style_index_0_id_4fc5ef0b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-style-loader/index.js??clonedRuleSet-22.use[0]!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!../../../node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!../../../node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true& */ \"./node_modules/vue-style-loader/index.js??clonedRuleSet-22.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true&\");\n/* harmony import */ var _node_modules_vue_style_loader_index_js_clonedRuleSet_22_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_22_use_1_node_modules_vue_vue_loader_v15_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_22_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_22_use_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_style_index_0_id_4fc5ef0b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_clonedRuleSet_22_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_22_use_1_node_modules_vue_vue_loader_v15_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_22_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_22_use_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_style_index_0_id_4fc5ef0b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);\n/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};\n/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_clonedRuleSet_22_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_22_use_1_node_modules_vue_vue_loader_v15_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_22_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_22_use_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_style_index_0_id_4fc5ef0b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== \"default\") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = function(key) { return _node_modules_vue_style_loader_index_js_clonedRuleSet_22_use_0_node_modules_css_loader_dist_cjs_js_clonedRuleSet_22_use_1_node_modules_vue_vue_loader_v15_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_22_use_2_node_modules_sass_loader_dist_cjs_js_clonedRuleSet_22_use_3_node_modules_vue_vue_loader_v15_lib_index_js_vue_loader_options_loginDialog_vue_vue_type_style_index_0_id_4fc5ef0b_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key]; }.bind(0, __WEBPACK_IMPORT_KEY__)\n/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);\n\n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?");

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n// const mutiLang = require(\"mutiLang\");\n// const cookie = require(\"cookie\");\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: \"LoginDialog\",\n  data: function () {\n    return {\n      src: \"\",\n      isLoading: true,\n      isShowLogin: false\n    };\n  },\n  props: [\"showLogin\"],\n\n  created() {\n    this.lang = \"en-us\";\n    let host = \"https://accounts.wondershare.com\";\n    this.loginSrc = `${host}/v3/user/oauth-client/authorize?redirect_uri=${window.location.origin}/callback.html&app_key=ede219e1b4e3eb875d74adddbaf41ec2&product_id=4358&mode=1&response_type=code&source=27&lang=${this.lang}`;\n    this.src = `${host}/web/cookie-check`;\n  },\n\n  mounted() {\n    this.$nextTick(() => {\n      window.addEventListener(\"message\", this.loginEvent);\n    });\n  },\n\n  watch: {\n    showLogin(newVal, oldVal) {\n      console.log(newVal, oldVal);\n      this.isShowLogin = newVal;\n    }\n\n  },\n  methods: {\n    loginEvent(data) {\n      if (data.data === \"3pc.unsupported\") {\n        window.location.href = `/sso/authorize?lang=en`;\n        setTimeout(() => {\n          this.$emit(\"close-login\");\n        }, 1500);\n      } else if (data.data === \"3pc.supported\") {\n        this.src = this.loginSrc;\n        this.$nextTick(() => {\n          this.$refs.iframe.onload = () => {\n            this.isLoading = false;\n          };\n        });\n      } else if (data.data === \"loginSuccessed\") {\n        this.$emit(\"login-success\");\n        this.$emit(\"close-login\");\n      }\n    }\n\n  },\n\n  handleClose(done) {\n    // done();\n    this.$emit(\"close-login\");\n  },\n\n  destroyed() {\n    window.removeEventListener(\"message\", this.loginEvent);\n  }\n\n});\n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/views/home/home.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/views/home/home.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _static_scripts_tools_cookie_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/static/scripts/tools/cookie.js */ \"./src/static/scripts/tools/cookie.js\");\n/* harmony import */ var _components_login_loginDialog_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components/login/loginDialog.vue */ \"./src/components/login/loginDialog.vue\");\n// import \"@/static/scripts/tools/userLogin.js\";\n\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  name: \"Home\",\n  components: {\n    LoginDialog: _components_login_loginDialog_vue__WEBPACK_IMPORTED_MODULE_1__[\"default\"]\n  },\n\n  data() {\n    return {\n      showLogin: false,\n      _login: null,\n      _login_a: null,\n      _user: null,\n      _user_avatar: null,\n      _user_item_4: null,\n      _user_pro: null,\n      UserType: {\n        free: 0,\n        register: 1,\n        vip: 2\n      },\n      userStatus: {},\n      hasUsedTrial: null\n    };\n  },\n\n  computed: {},\n\n  created() {},\n\n  mounted() {\n    this.$nextTick(() => {\n      this._login = document.getElementsByClassName(\"wondershare-user-panel\")[0];\n      this._login_a = this._login.getElementsByClassName(\"wsc-header2020-navbar-link\")[0];\n      this._user = document.getElementsByClassName(\"wondershare-user-panel\")[1];\n      this._user_avatar = this._user.getElementsByClassName(\"avatar\")[0];\n      this._user_pro = this._user.getElementsByClassName(\"pro\")[0];\n\n      let _user_item_ul = this._user.getElementsByClassName(\"item1\")[0];\n\n      let _user_item_1 = _user_item_ul.getElementsByTagName(\"a\")[0];\n\n      _user_item_1.href = \"https://accounts.wondershare.com/web/profile\";\n\n      let _user_item_2 = _user_item_ul.getElementsByTagName(\"a\")[1];\n\n      _user_item_2.href = \"/last-proceed-files\";\n\n      let _user_item_3 = _user_item_ul.getElementsByTagName(\"a\")[2];\n\n      _user_item_3.href = \"/order\";\n      this._user_item_4 = _user_item_ul.getElementsByTagName(\"a\")[3];\n      console.log(this._user_item_4);\n      this.initUserStatus();\n      this.initUserEvent();\n    });\n  },\n\n  watch: {},\n  methods: {\n    initUserStatus() {\n      console.log(\"cookie===>\", _static_scripts_tools_cookie_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"]);\n      let user = _static_scripts_tools_cookie_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"].getUserInfo();\n      console.log(\"user===>\", user);\n\n      if (!user) {\n        this._login.classList.remove(\"d-none\");\n\n        this._user.classList.add(\"d-none\");\n      } else {\n        this._login.classList.add(\"d-none\");\n\n        this._user.classList.remove(\"d-none\");\n\n        this.initLoginStatus();\n      }\n    },\n\n    initUserEvent() {\n      let _this = this;\n\n      if (this._login_a) {\n        this._login_a.onclick = function (e) {\n          if (e.preventDefault) {\n            e.preventDefault();\n          } else {\n            e.returnValue = false;\n          }\n\n          _this.showLogin = true;\n        };\n\n        this._user_item_4.onclick = function (e) {\n          if (e.preventDefault) {\n            e.preventDefault();\n          } else {\n            e.returnValue = false;\n          }\n\n          _this.logoutSuccess();\n        };\n      }\n    },\n\n    loginClose() {\n      this.showLogin = false;\n    },\n\n    loginSuccess() {\n      this.initLoginStatus();\n      this.initUserStatus();\n      this.isLogin = true;\n    },\n\n    initLoginStatus() {\n      let user = _static_scripts_tools_cookie_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"].getUserInfo();\n      console.log(\"user===>\", user);\n\n      if (user) {\n        this._user_avatar.src = this.setAvatar(user.avatar);\n\n        if (user.pay) {\n          // this.isFree = false;\n          this.userStatus = this.UserType.vip;\n\n          this._user_pro.classList.remove(\"d-none\");\n        } else {\n          this.userStatus = this.UserType.register;\n        }\n\n        this.isLogin = true;\n        this.hasUsedTrial = !!user.has_used_trial || user.pay;\n      } else {\n        this.isLogin = false;\n        this.userStatus = this.UserType.free;\n        this.hasUsedTrial = false;\n      } // this.$store.dispatch(\"user/userAsyncSet\", { userType: this.userStatus });\n\n    },\n\n    logoutSuccess() {\n      console.log(\"111\");\n      window.open(`/sso/logout`, \"_self\");\n    },\n\n    setAvatar: function (dataAvatar) {\n      let avatar = \"\";\n\n      if (dataAvatar) {\n        avatar = dataAvatar;\n      } else {\n        avatar = \"/static/images/new/defaultImages.svg\";\n      }\n\n      return avatar;\n    }\n  }\n});\n\n//# sourceURL=webpack://hipdf/./src/views/home/home.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=template&id=4fc5ef0b&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": function() { return /* binding */ render; },\n/* harmony export */   \"staticRenderFns\": function() { return /* binding */ staticRenderFns; }\n/* harmony export */ });\nvar render = function render() {\n  var _vm = this,\n      _c = _vm._self._c;\n\n  return _c(\"el-dialog\", {\n    attrs: {\n      title: \"\",\n      visible: _vm.isShowLogin,\n      width: \"30%\"\n    },\n    on: {\n      \"update:visible\": function ($event) {\n        _vm.isShowLogin = $event;\n      },\n      close: function ($event) {\n        return _vm.$emit(\"close-login\");\n      }\n    }\n  }, [_c(\"div\", {\n    staticClass: \"mei-dialog-content\"\n  }, [_c(\"iframe\", {\n    directives: [{\n      name: \"show\",\n      rawName: \"v-show\",\n      value: !_vm.isLoading,\n      expression: \"!isLoading\"\n    }],\n    ref: \"iframe\",\n    attrs: {\n      src: _vm.src,\n      frameborder: \"0\"\n    }\n  }), _c(\"span\", {\n    directives: [{\n      name: \"show\",\n      rawName: \"v-show\",\n      value: _vm.isLoading,\n      expression: \"isLoading\"\n    }],\n    staticClass: \"typing_loader\"\n  })])]);\n};\n\nvar staticRenderFns = [];\nrender._withStripped = true;\n\n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/views/home/home.vue?vue&type=template&id=39f87be5&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[0]!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet[1].rules[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/views/home/home.vue?vue&type=template&id=39f87be5&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": function() { return /* binding */ render; },\n/* harmony export */   \"staticRenderFns\": function() { return /* binding */ staticRenderFns; }\n/* harmony export */ });\nvar render = function render() {\n  var _vm = this,\n      _c = _vm._self._c;\n\n  return _c(\"div\", {\n    attrs: {\n      id: \"app-login\"\n    }\n  }, [_c(\"Login-Dialog\", {\n    attrs: {\n      showLogin: _vm.showLogin\n    },\n    on: {\n      \"close-login\": _vm.loginClose,\n      \"login-success\": _vm.loginSuccess\n    }\n  })], 1);\n};\n\nvar staticRenderFns = [];\nrender._withStripped = true;\n\n\n//# sourceURL=webpack://hipdf/./src/views/home/home.vue?./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use%5B0%5D!./node_modules/@vue/vue-loader-v15/lib/loaders/templateLoader.js??ruleSet%5B1%5D.rules%5B3%5D!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./src/static/scripts/tools/base64.js":
/*!********************************************!*\
  !*** ./src/static/scripts/tools/base64.js ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Base64\": function() { return /* binding */ Base64; }\n/* harmony export */ });\nfunction base64() {\n  // private property\n  var _keyStr = \"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\"; // public method for encoding\n\n  this.encode = function (input) {\n    var output = \"\";\n    var chr1, chr2, chr3, enc1, enc2, enc3, enc4;\n    var i = 0;\n    input = this._utf8_encode(input);\n\n    while (i < input.length) {\n      chr1 = input.charCodeAt(i++);\n      chr2 = input.charCodeAt(i++);\n      chr3 = input.charCodeAt(i++);\n      enc1 = chr1 >> 2;\n      enc2 = (chr1 & 3) << 4 | chr2 >> 4;\n      enc3 = (chr2 & 15) << 2 | chr3 >> 6;\n      enc4 = chr3 & 63;\n\n      if (isNaN(chr2)) {\n        enc3 = enc4 = 64;\n      } else if (isNaN(chr3)) {\n        enc4 = 64;\n      }\n\n      output = output + _keyStr.charAt(enc1) + _keyStr.charAt(enc2) + _keyStr.charAt(enc3) + _keyStr.charAt(enc4);\n    }\n\n    return output;\n  }; // public method for decoding\n\n\n  this.decode = function (input) {\n    var output = \"\";\n    var chr1, chr2, chr3;\n    var enc1, enc2, enc3, enc4;\n    var i = 0;\n    input = input.replace(/[^A-Za-z0-9\\+\\/\\=]/g, \"\");\n\n    while (i < input.length) {\n      enc1 = _keyStr.indexOf(input.charAt(i++));\n      enc2 = _keyStr.indexOf(input.charAt(i++));\n      enc3 = _keyStr.indexOf(input.charAt(i++));\n      enc4 = _keyStr.indexOf(input.charAt(i++));\n      chr1 = enc1 << 2 | enc2 >> 4;\n      chr2 = (enc2 & 15) << 4 | enc3 >> 2;\n      chr3 = (enc3 & 3) << 6 | enc4;\n      output = output + String.fromCharCode(chr1);\n\n      if (enc3 != 64) {\n        output = output + String.fromCharCode(chr2);\n      }\n\n      if (enc4 != 64) {\n        output = output + String.fromCharCode(chr3);\n      }\n    }\n\n    output = this._utf8_decode(output);\n    return output;\n  }; // private method for UTF-8 encoding\n\n\n  this._utf8_encode = function (string) {\n    string = string.replace(/\\r\\n/g, \"\\n\");\n    var utftext = \"\";\n\n    for (var n = 0; n < string.length; n++) {\n      var c = string.charCodeAt(n);\n\n      if (c < 128) {\n        utftext += String.fromCharCode(c);\n      } else if (c > 127 && c < 2048) {\n        utftext += String.fromCharCode(c >> 6 | 192);\n        utftext += String.fromCharCode(c & 63 | 128);\n      } else {\n        utftext += String.fromCharCode(c >> 12 | 224);\n        utftext += String.fromCharCode(c >> 6 & 63 | 128);\n        utftext += String.fromCharCode(c & 63 | 128);\n      }\n    }\n\n    return utftext;\n  }; // private method for UTF-8 decoding\n\n\n  this._utf8_decode = function (utftext) {\n    var string = \"\";\n    var i = 0;\n    var c = 0,\n        c1 = 0,\n        c2 = 0,\n        c3;\n\n    while (i < utftext.length) {\n      c = utftext.charCodeAt(i);\n\n      if (c < 128) {\n        string += String.fromCharCode(c);\n        i++;\n      } else if (c > 191 && c < 224) {\n        c2 = utftext.charCodeAt(i + 1);\n        string += String.fromCharCode((c & 31) << 6 | c2 & 63);\n        i += 2;\n      } else {\n        c2 = utftext.charCodeAt(i + 1);\n        c3 = utftext.charCodeAt(i + 2);\n        string += String.fromCharCode((c & 15) << 12 | (c2 & 63) << 6 | c3 & 63);\n        i += 3;\n      }\n    }\n\n    return string;\n  };\n}\n\nconst Base64 = new base64();\n\n//# sourceURL=webpack://hipdf/./src/static/scripts/tools/base64.js?");

/***/ }),

/***/ "./src/static/scripts/tools/cookie.js":
/*!********************************************!*\
  !*** ./src/static/scripts/tools/cookie.js ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _static_scripts_tools_base64_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/static/scripts/tools/base64.js */ \"./src/static/scripts/tools/base64.js\");\n\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\n  setCookie: function (cname, cvalue, exdays) {\n    var d = new Date();\n    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);\n    var expires = \"expires=\" + d.toUTCString();\n    document.cookie = cname + \"=\" + cvalue + \";\" + expires + \";path=/\";\n  },\n  delCookie: function (key) {\n    var date = new Date();\n    date.setTime(date.getTime() - 1);\n    var delValue = this.getCookie(key);\n\n    if (!!delValue) {\n      document.cookie = key + '=' + delValue + ';expires=' + date.toGMTString();\n    }\n  },\n  getCookie: function (cname) {\n    var name = cname + \"=\";\n    var decodedCookie = decodeURIComponent(document.cookie);\n    var ca = decodedCookie.split(';');\n\n    for (var i = 0; i < ca.length; i++) {\n      var c = ca[i];\n\n      while (c.charAt(0) == ' ') {\n        c = c.substring(1);\n      }\n\n      if (c.indexOf(name) == 0) {\n        return c.substring(name.length, c.length);\n      }\n    }\n\n    return \"\";\n  },\n  cookieDecode: function (cdata) {\n    var arr1 = cdata.split('|');\n\n    if (arr1 && arr1[arr1.length - 2]) {\n      var arr2 = arr1[arr1.length - 2].split(':');\n\n      if (arr2[1]) {\n        var arr3Str = _static_scripts_tools_base64_js__WEBPACK_IMPORTED_MODULE_0__.Base64.decode(arr2[1]);\n\n        if (arr3Str) {\n          var arr3 = JSON.parse(arr3Str);\n          return arr3;\n        }\n      }\n    }\n\n    return null;\n  },\n  getCommonUser: function () {\n    var ucp = this.getCookie('ucp');\n\n    if (!ucp) {\n      return null;\n    }\n\n    return this.cookieDecode(ucp); // var arr1 = ucp.split('|');\n    // if (arr1 && arr1[arr1.length - 2]) {\n    //     var arr2 = arr1[arr1.length - 2].split(':');\n    //     if (arr2[1]) {\n    //         var userStr = base64.decode(arr2[1]);\n    //         if (userStr) {\n    //             var user = JSON.parse(userStr);\n    //             return user;\n    //         }\n    //     }\n    // }\n    // return null;\n  },\n  getUserInfo: function () {\n    var user = this.getCommonUser();\n\n    if (user && (user.email || !!user.ws_id)) {\n      // 判断是否付费\n      user.pay = false;\n\n      if (user.have_permission) {\n        user.pay = true;\n      }\n\n      return user;\n    }\n\n    return null;\n  },\n  getUserShare: function () {\n    var ucp = this.getCookie('ucp');\n\n    if (!ucp) {\n      return null;\n    }\n\n    var user = this.cookieDecode(ucp);\n\n    if (user && user.s) {\n      return user;\n    }\n\n    return null;\n  },\n  getExpiration: function () {\n    var timeExpiration = this.getCookie('uca');\n\n    if (!timeExpiration) {\n      return;\n    }\n\n    return this.cookieDecode(timeExpiration);\n  }\n});\n\n//# sourceURL=webpack://hipdf/./src/static/scripts/tools/cookie.js?");

/***/ }),

/***/ "./src/views/home/index.js":
/*!*********************************!*\
  !*** ./src/views/home/index.js ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var element_ui_lib_theme_chalk_dialog_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! element-ui/lib/theme-chalk/dialog.css */ \"./node_modules/element-ui/lib/theme-chalk/dialog.css\");\n/* harmony import */ var element_ui_lib_theme_chalk_dialog_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(element_ui_lib_theme_chalk_dialog_css__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var element_ui_lib_theme_chalk_base_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! element-ui/lib/theme-chalk/base.css */ \"./node_modules/element-ui/lib/theme-chalk/base.css\");\n/* harmony import */ var element_ui_lib_theme_chalk_base_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(element_ui_lib_theme_chalk_base_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var element_ui_lib_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! element-ui/lib/dialog */ \"./node_modules/element-ui/lib/dialog.js\");\n/* harmony import */ var element_ui_lib_dialog__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(element_ui_lib_dialog__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var element_ui_lib_theme_chalk_button_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! element-ui/lib/theme-chalk/button.css */ \"./node_modules/element-ui/lib/theme-chalk/button.css\");\n/* harmony import */ var element_ui_lib_theme_chalk_button_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(element_ui_lib_theme_chalk_button_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var element_ui_lib_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! element-ui/lib/button */ \"./node_modules/element-ui/lib/button.js\");\n/* harmony import */ var element_ui_lib_button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(element_ui_lib_button__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.runtime.esm.js\");\n/* harmony import */ var _home_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.vue */ \"./src/views/home/home.vue\");\n\n\n\n\n\n\n\n\nvue__WEBPACK_IMPORTED_MODULE_6__[\"default\"].use((element_ui_lib_button__WEBPACK_IMPORTED_MODULE_4___default()));\nvue__WEBPACK_IMPORTED_MODULE_6__[\"default\"].use((element_ui_lib_dialog__WEBPACK_IMPORTED_MODULE_2___default()));\nvue__WEBPACK_IMPORTED_MODULE_6__[\"default\"].config.productionTip = false;\nnew vue__WEBPACK_IMPORTED_MODULE_6__[\"default\"]({\n  render: h => h(_home_vue__WEBPACK_IMPORTED_MODULE_5__[\"default\"])\n}).$mount('#app-login');\n\n//# sourceURL=webpack://hipdf/./src/views/home/index.js?");

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/noSourceMaps.js */ \"./node_modules/css-loader/dist/runtime/noSourceMaps.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ \"./node_modules/css-loader/dist/runtime/api.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);\n// Imports\n\n\nvar ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));\n// Module\n___CSS_LOADER_EXPORT___.push([module.id, \".typing_loader[data-v-4fc5ef0b] {\\n  width: 8px;\\n  height: 8px;\\n  line-height: 8px;\\n  display: inline-block;\\n  border-radius: 50%;\\n  -webkit-animation: ptyping-4fc5ef0b 1s linear infinite alternate;\\n          animation: ptyping-4fc5ef0b 1s linear infinite alternate;\\n  position: absolute;\\n  left: 50%;\\n  top: 50%;\\n  transform: translate(-50%, -50%);\\n  margin-left: -11px;\\n}\\n@-webkit-keyframes ptyping-4fc5ef0b {\\n0% {\\n    background-color: rgb(67, 91, 253);\\n    box-shadow: 12px 0px 0px 0px rgba(67, 91, 253, 0.2), 24px 0px 0px 0px rgba(67, 91, 253, 0.2);\\n}\\n25% {\\n    background-color: rgba(67, 91, 253, 0.4);\\n    box-shadow: 12px 0px 0px 0px rgb(67, 91, 253), 24px 0px 0px 0px rgba(67, 91, 253, 0.2);\\n}\\n75% {\\n    background-color: rgba(67, 91, 253, 0.4);\\n    box-shadow: 12px 0px 0px 0px rgba(67, 91, 253, 0.2), 24px 0px 0px 0px rgb(67, 91, 253);\\n}\\n}\\n@keyframes ptyping-4fc5ef0b {\\n0% {\\n    background-color: rgb(67, 91, 253);\\n    box-shadow: 12px 0px 0px 0px rgba(67, 91, 253, 0.2), 24px 0px 0px 0px rgba(67, 91, 253, 0.2);\\n}\\n25% {\\n    background-color: rgba(67, 91, 253, 0.4);\\n    box-shadow: 12px 0px 0px 0px rgb(67, 91, 253), 24px 0px 0px 0px rgba(67, 91, 253, 0.2);\\n}\\n75% {\\n    background-color: rgba(67, 91, 253, 0.4);\\n    box-shadow: 12px 0px 0px 0px rgba(67, 91, 253, 0.2), 24px 0px 0px 0px rgb(67, 91, 253);\\n}\\n}\\n[data-v-4fc5ef0b] .el-dialog {\\n  width: 450px !important;\\n  height: 610px;\\n}\\n[data-v-4fc5ef0b] .el-dialog .el-dialog__header {\\n  padding: 0;\\n}\\n[data-v-4fc5ef0b] .el-dialog .el-dialog__body {\\n  height: 100%;\\n  padding: 0;\\n}\\n[data-v-4fc5ef0b] .el-dialog .el-dialog__body .mei-dialog-content {\\n  height: 100%;\\n}\\n[data-v-4fc5ef0b] .el-dialog .el-dialog__body .mei-dialog-content iframe {\\n  height: 100%;\\n  width: 100%;\\n}\", \"\"]);\n// Exports\n/* harmony default export */ __webpack_exports__[\"default\"] = (___CSS_LOADER_EXPORT___);\n\n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use%5B1%5D!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use%5B2%5D!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use%5B3%5D!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js??clonedRuleSet-22.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js??clonedRuleSet-22.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval("// style-loader: Adds some css to the DOM by adding a <style> tag\n\n// load the styles\nvar content = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!../../../node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!../../../node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!../../../node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true& */ \"./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options!./src/components/login/loginDialog.vue?vue&type=style&index=0&id=4fc5ef0b&lang=scss&scoped=true&\");\nif(content.__esModule) content = content.default;\nif(typeof content === 'string') content = [[module.id, content, '']];\nif(content.locals) module.exports = content.locals;\n// add the styles to the DOM\nvar add = (__webpack_require__(/*! !../../../node_modules/vue-style-loader/lib/addStylesClient.js */ \"./node_modules/vue-style-loader/lib/addStylesClient.js\")[\"default\"])\nvar update = add(\"0885c94e\", content, false, {\"sourceMap\":false,\"shadowMode\":false});\n// Hot Module Replacement\nif(false) {}\n\n//# sourceURL=webpack://hipdf/./src/components/login/loginDialog.vue?./node_modules/vue-style-loader/index.js??clonedRuleSet-22.use%5B0%5D!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use%5B1%5D!./node_modules/@vue/vue-loader-v15/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use%5B2%5D!./node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use%5B3%5D!./node_modules/@vue/vue-loader-v15/lib/index.js??vue-loader-options");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	!function() {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = function(result, chunkIds, fn, priority) {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var chunkIds = deferred[i][0];
/******/ 				var fn = deferred[i][1];
/******/ 				var priority = deferred[i][2];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every(function(key) { return __webpack_require__.O[key](chunkIds[j]); })) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	!function() {
/******/ 		__webpack_require__.p = "/";
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	!function() {
/******/ 		__webpack_require__.b = document.baseURI || self.location.href;
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"home": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = function(chunkId) { return installedChunks[chunkId] === 0; };
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = function(parentChunkLoadingFunction, data) {
/******/ 			var chunkIds = data[0];
/******/ 			var moreModules = data[1];
/******/ 			var runtime = data[2];
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some(function(id) { return installedChunks[id] !== 0; })) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkhipdf"] = self["webpackChunkhipdf"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["chunk-vendors"], function() { return __webpack_require__("./src/views/home/index.js"); })
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;